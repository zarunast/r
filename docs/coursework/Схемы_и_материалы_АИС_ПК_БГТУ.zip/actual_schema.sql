-- Реальная схема версии 0.3.0. Сгенерирована из SQLAlchemy metadata.

PRAGMA foreign_keys = ON;

CREATE TABLE activity_events (
	id INTEGER NOT NULL, 
	at DATETIME NOT NULL, 
	actor VARCHAR NOT NULL, 
	action VARCHAR NOT NULL, 
	object VARCHAR NOT NULL, 
	detail VARCHAR NOT NULL, 
	status VARCHAR NOT NULL, 
	PRIMARY KEY (id)
);

CREATE INDEX ix_activity_events_at ON activity_events (at);

CREATE TABLE applicants (
	number VARCHAR(64) NOT NULL, 
	surname VARCHAR NOT NULL, 
	first_name VARCHAR NOT NULL, 
	patronymic VARCHAR NOT NULL, 
	profile JSON NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (number)
);

CREATE INDEX ix_applicants_surname ON applicants (surname);

CREATE TABLE seat_plans (
	id INTEGER NOT NULL, 
	year INTEGER NOT NULL, 
	campaign VARCHAR NOT NULL, 
	direction VARCHAR NOT NULL, 
	study_form VARCHAR NOT NULL, 
	quota VARCHAR NOT NULL, 
	seats INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (year, campaign, direction, study_form, quota)
);

CREATE TABLE users (
	id INTEGER NOT NULL, 
	login VARCHAR NOT NULL, 
	password_hash VARCHAR NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (login)
);

CREATE TABLE applications (
	id INTEGER NOT NULL, 
	applicant_number VARCHAR(64) NOT NULL, 
	year INTEGER NOT NULL, 
	campaign VARCHAR NOT NULL, 
	direction VARCHAR NOT NULL, 
	study_form VARCHAR NOT NULL, 
	quota VARCHAR NOT NULL, 
	priority INTEGER NOT NULL, 
	status VARCHAR NOT NULL, 
	total_score INTEGER NOT NULL, 
	achievements INTEGER NOT NULL, 
	exams JSON NOT NULL, 
	consent BOOLEAN NOT NULL, 
	enrolled_at DATETIME, 
	source JSON NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (applicant_number, year, campaign, direction, study_form, quota), 
	FOREIGN KEY(applicant_number) REFERENCES applicants (number)
);

CREATE INDEX ix_ranking ON applications (year, direction, quota, status, total_score);

CREATE INDEX ix_applications_applicant_number ON applications (applicant_number);

CREATE TABLE calls (
	id INTEGER NOT NULL, 
	application_id INTEGER NOT NULL, 
	result VARCHAR NOT NULL, 
	comment VARCHAR NOT NULL, 
	actor VARCHAR NOT NULL, 
	at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(application_id) REFERENCES applications (id)
);

CREATE INDEX ix_calls_application_id ON calls (application_id);

CREATE TABLE contracts (
	id INTEGER NOT NULL, 
	number VARCHAR NOT NULL, 
	application_id INTEGER NOT NULL, 
	location VARCHAR NOT NULL, 
	stage VARCHAR NOT NULL, 
	paid BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (number), 
	UNIQUE (application_id), 
	FOREIGN KEY(application_id) REFERENCES applications (id)
);

CREATE TABLE contract_events (
	id INTEGER NOT NULL, 
	contract_id INTEGER NOT NULL, 
	at DATETIME NOT NULL, 
	actor VARCHAR NOT NULL, 
	changes JSON NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(contract_id) REFERENCES contracts (id)
);

CREATE INDEX ix_contract_events_contract_id ON contract_events (contract_id);
